window.addEventListener('load', function() {
    var fadeText = document.getElementById('fadeText');
    fadeText.style.opacity = 1;
  });
  